Translation Workflow
====================

If documentation changed, run `make push` to push new messages to transiflex (manager account required).

To update the local translation files, call `make pull` and commit the changes from time to time  (manager account required).

Go to https://www.transifex.com/bottle for actually translating stuff. You can du that with a normal user account at transiflex.
